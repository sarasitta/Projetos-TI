package Banco_Dados_MySql;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JRootPane;

public class NFrame extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8206775205698509929L;
	public NFrame()
	{
		setLocation(250,100);
		setTitle("JFrame personalizado");
		setBounds(0,0,600,450);
		setUndecorated(true);
		getRootPane().setWindowDecorationStyle(JRootPane.INFORMATION_DIALOG);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.black,5));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	public static void main(String arg[])
	{
		new NFrame().setVisible(true);
	}
}
