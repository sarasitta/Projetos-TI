CREATE DATABASE  IF NOT EXISTS `produto` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `produto`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: produto
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fornecedor`
--

DROP TABLE IF EXISTS `fornecedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fornecedor` (
  `Cod_For` int(11) NOT NULL,
  `Nome_For` varchar(45) DEFAULT NULL,
  `RazSoc_For` varchar(45) DEFAULT NULL,
  `Cnpj_For` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Cod_For`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedor`
--

LOCK TABLES `fornecedor` WRITE;
/*!40000 ALTER TABLE `fornecedor` DISABLE KEYS */;
INSERT INTO `fornecedor` VALUES (1,'Bujão','Bujão Comercio ','59.123.134/0001-57'),(2,'Furia Espanhola','Toberrone Cia','43.145.789/0001-45');
/*!40000 ALTER TABLE `fornecedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabprod`
--

DROP TABLE IF EXISTS `tabprod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabprod` (
  `CodProd` int(11) NOT NULL,
  `NomeProd` varchar(45) DEFAULT NULL,
  `DescProd` varchar(45) DEFAULT NULL,
  `Valor` varchar(45) DEFAULT NULL,
  `CodFor` int(11) DEFAULT NULL,
  PRIMARY KEY (`CodProd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabprod`
--

LOCK TABLES `tabprod` WRITE;
/*!40000 ALTER TABLE `tabprod` DISABLE KEYS */;
INSERT INTO `tabprod` VALUES (1,'CANETA AZUL','CANETA BIC AZUL','4.5',1),(2,'CANETA VERMELHA','CANETA BIC VERMELHA','4.5',1),(3,'CANETA VERDE','CANETA BIC VEDE','4.5',1),(4,'CANETA PRETA','CANETA BIC PRETA','4.5',1),(5,'MARCADOR TEXTO','MARCADOR TEXTO AZUL','5.55',2),(6,'MARCADOR TEXO','MARCADOR TEXTO AMARELO','5.55',2),(7,'SULFITE A4','PACOTE C/500 FLS','14.55',2),(8,'SULFITE A3','PACOTE C500','17.67',3),(9,'PINCEL PILOT','PINCEL P QUADRO BRANCO AZUL','5.55',4),(10,'PINCEL PILOT','PINCEL P QUADRO BRANCO PRETO','5.55',4),(11,'PINCEL PILOT','PINCEL P QUADRO BRANCO VERMELHO','5.55',4),(12,'PINCEL PILOT','PINCEL P QUADRO BRANCO VERDE','5.55',4),(13,'RECARGA PINCEL','RECARGA PINCEL AZUL','4.00',4),(14,'RECARGA PINCEL','RECARGA PINCEL PRETO','4.00',4),(15,'RECARGA PINCEL','RECARGA PINCEL VERMELHO','4.00',4),(16,'PAPEL CANSON ','PAPELA CANSON A4','3.50',5);
/*!40000 ALTER TABLE `tabprod` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-27  7:57:43
