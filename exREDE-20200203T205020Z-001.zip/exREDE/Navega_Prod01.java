package Banco_Dados_MySql;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTextField;



public class Navega_Prod01 extends NFrame implements ActionListener
{
  
private static final long serialVersionUID = 1L;
  JLabel label1,label2,label3,label4,label5;
  JButton btProximo,btAnterior,btPrimeiro,btUltimo,btMais10,btMenos10,btSair;
  JTextField tfCodigo,tfProduto,tfDesc,tfPreco,tfCodFor;
  JPanel p1 = new JPanel();
    
    Navega_Prod01()
  {   
	setTitle("Navega��o da tabela de Produtos");
	setBounds(0,0,600,120);
	setResizable(false);  
	  
    p1.setLayout(new FlowLayout(FlowLayout.LEFT));
    
    label1 = new JLabel("Codigo        ");
    label2 = new JLabel("Produto");
    label3 = new JLabel("Descri��o  ");
    label4 = new JLabel("Valor    ");
    label5 = new JLabel("Fornecedor");
    
    tfCodigo = new JTextField(10);
    tfCodigo.addActionListener(this); 
    tfProduto = new JTextField(30);
    tfDesc= new JTextField(30);
    tfPreco = new JTextField(10);
    tfCodFor = new JTextField(5);
    
    btProximo=new JButton("Pr�ximo");    
    btProximo = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/images/proximo.gif"));
    btProximo.setToolTipText("Pr�ximo");
    
    btAnterior=new JButton("Anterior");
    btAnterior = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/images/anterior.gif"));
    btAnterior.setToolTipText("Anterior");
    
    btPrimeiro=new JButton("Primeiro");
    btPrimeiro = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/primeiro.gif"));
    btPrimeiro.setToolTipText("Primeiro");
    
    btUltimo=new JButton("�ltimo");
    btUltimo = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/ultimo.gif"));
    btUltimo.setToolTipText("Ultimo");
    
    btMais10=new JButton("+10 registros");
    btMais10 = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/mais.png"));
    btMais10.setToolTipText("+10");
    
    btMenos10=new JButton("-10 registros");
    btMenos10 = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/images/menos.png"));
    btMenos10.setToolTipText("-10");
    
    btSair = new JButton(null,new ImageIcon
    		("D:/ETEC - 2018/3EETIMPRC/Programa��o Java/src/Banco_Dados_MySql/images/sair.png"));
    btSair.setToolTipText("Sair");
    
    btProximo.addActionListener(this);    
    btAnterior.addActionListener(this);
    btPrimeiro.addActionListener(this);    
    btUltimo.addActionListener(this);
    btMais10.addActionListener(this);    
    btMenos10.addActionListener(this);
    btSair.addActionListener(this);
    
    p1.add(label1);
    p1.add(tfCodigo); 
    p1.add(label2);     
    p1.add(tfProduto);
    p1.add(label3);
    p1.add(tfDesc); 
    p1.add(label4);
    p1.add(tfPreco);
    p1.add(label5);    
    p1.add(tfCodFor);
    p1.add(btPrimeiro);
    p1.add(btAnterior); 
    p1.add(btProximo);
    p1.add(btUltimo);
    p1.add(btMais10);   
    p1.add(btMenos10);
    p1.add(btSair);
    
    getContentPane().add(p1);
	
    if (!BD.getConnection())
    {
      JOptionPane.showMessageDialog(null, "Falha na conex�o, o sistema ser� fechado!");
      System.exit(0);
    }
    BD.setResultSet("select * from TabProd");
  }    

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      if (e.getSource()==btProximo) 
        BD.resultSet.next();         // vai para o pr�ximo
      if (e.getSource()==btAnterior) 
        BD.resultSet.previous();     // volta para o anterior
      if (e.getSource()==btPrimeiro) 
        BD.resultSet.first();        // vai para o primeiro
      if (e.getSource()==btUltimo) 
        BD.resultSet.last();         // vai para o �ltimo
      if (e.getSource()==btMais10) 
        BD.resultSet.relative(10);   // adianta 10 registros
      if (e.getSource()==btMenos10)
        BD.resultSet.relative(-10);  // retorna 10 registros   
      atualizaCampos(); 
      if(e.getSource()==btSair) // Finaliza a aplica��o
        System.exit(0);
    } 
    catch(SQLException erro)    {
      erro.printStackTrace();
    }  
  }	
  
  public void atualizaCampos()
  {
    try
    {
      if (BD.resultSet.isAfterLast())
          BD.resultSet.last();
      if (BD.resultSet.isBeforeFirst())
          BD.resultSet.first();
          tfCodigo.setText(BD.resultSet.getString("CodProd"));
          tfProduto.setText(BD.resultSet.getString("NomeProd"));
          tfDesc.setText(BD.resultSet.getString("DescProd"));
          tfPreco.setText(BD.resultSet.getString("valor"));
          tfCodFor.setText(""+BD.resultSet.getString("Codfor"));
    }	
    catch(SQLException erro)  { }
  	} 


public static void main(String args[])
{
  JFrame janela = new Navega_Prod01();
  Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
  janela.setLocation((tela.width-janela.getSize().width)/2,(tela.height-janela.getSize().height)/2);
  janela.setUndecorated(true);
  janela.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);
  janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
  janela.setVisible(true);
}
}