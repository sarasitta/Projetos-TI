import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class Pedidos extends JFrame {
	JPanel pnPrincipal, pnTable;
	JButton btRemover, btAdicionar;
	JScrollPane scrollTable;
	JTable table;
	JLabel lbNumero, lbTotal, lbProduto, lbPrecoUnitario, lbQuantidade;
	JTextField tfNumero, tfTotal, tfProduto, tfPrecoUnitario, tfQuantidade;
	DecimalFormat df = new DecimalFormat("#,###.00");

	public Pedidos() {
		setBounds(150, 50, 500, 450);
		setResizable(false);
		getContentPane().setBackground(new Color(220, 220, 220));
		getContentPane().setLayout(null);

		lbProduto = new JLabel("Produto");
		lbQuantidade = new JLabel("Quantidade");
		lbPrecoUnitario = new JLabel("Pre�o Unit�rio");
		lbNumero = new JLabel("N�mero do Pedido");
		lbTotal = new JLabel("Total do Pedido");

		tfProduto = new JTextField();
		tfPrecoUnitario = new JTextField();
		tfQuantidade = new JTextField();
		tfNumero = new JTextField();
		tfTotal = new JTextField();
		tfTotal.setEnabled(false);
		tfTotal.setHorizontalAlignment(SwingConstants.RIGHT);

		btAdicionar = new JButton("Adicionar");
		btAdicionar.setToolTipText("Adiciona um item ao pedido");
		btRemover = new JButton("Remover");
		btRemover.setToolTipText("Remove os itens selecionados");

		lbProduto.setBounds(15, 40, 100, 25);
		lbQuantidade.setBounds(225, 40, 100, 25);
		lbPrecoUnitario.setBounds(310, 40, 100, 25);
		lbNumero.setBounds(15, 10, 120, 25);
		lbTotal.setBounds(278, 360, 100, 25);

		tfProduto.setBounds(15, 65, 200, 25);
		tfQuantidade.setBounds(225, 65, 70, 25);
		tfPrecoUnitario.setBounds(310, 65, 90, 25);
		tfNumero.setBounds(130, 10, 50, 25);
		tfTotal.setBounds(375, 360, 100, 25);

		btAdicionar.setBounds(15, 100, 100, 22);
		btRemover.setBounds(125, 100, 100, 22);

		pnPrincipal = new JPanel();
		pnPrincipal.setLayout(null);
		pnPrincipal.setBounds(0, 0, 500, 400);

		pnPrincipal.add(lbNumero);
		pnPrincipal.add(lbTotal);
		pnPrincipal.add(tfNumero);
		pnPrincipal.add(tfTotal);
		pnPrincipal.add(lbProduto);
		pnPrincipal.add(tfProduto);
		pnPrincipal.add(lbQuantidade);
		pnPrincipal.add(tfQuantidade);
		pnPrincipal.add(lbPrecoUnitario);
		pnPrincipal.add(tfPrecoUnitario);

		pnTable = new JPanel(new BorderLayout());
		pnTable.setBorder(new TitledBorder("Itens do Pedido"));
		scrollTable = new JScrollPane();
		df.setMinimumFractionDigits(2);
		df.setMaximumFractionDigits(2);
		pnPrincipal.add(btAdicionar);
		pnPrincipal.add(btRemover);

		DefaultTableModel tableModel = new DefaultTableModel(
				new String[] { "Item", "Produto", "Qtde.", "Pre�o Un.", "Total" }, 0) {

			public boolean isCellEditable(int row, int col) {
				if (col == 4) {
					return false;
				}
				return true;
			}
		};

		table = new JTable(tableModel);
		DefaultTableCellRenderer alinhaDireita = new DefaultTableCellRenderer();
		alinhaDireita.setHorizontalAlignment(SwingConstants.RIGHT);
		DefaultTableCellRenderer alinhaCentro = new DefaultTableCellRenderer();
		alinhaCentro.setHorizontalAlignment(SwingConstants.CENTER);

		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(0).setCellRenderer(alinhaCentro);

		table.getColumnModel().getColumn(1).setPreferredWidth(150);

		table.getColumnModel().getColumn(2).setPreferredWidth(57);
		table.getColumnModel().getColumn(2).setCellRenderer(alinhaCentro);

		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setCellRenderer(alinhaDireita);

		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setCellRenderer(alinhaDireita);

		table.getTableHeader().setResizingAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		scrollTable.setViewportView(table);
		pnTable.add(scrollTable);
		pnTable.setBounds(10, 130, 470, 230);
		pnPrincipal.add(pnTable);
		add(pnPrincipal);

		btAdicionar.registerKeyboardAction(
				btAdicionar.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0, false)),
				KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), JComponent.WHEN_FOCUSED);
		btAdicionar.registerKeyboardAction(
				btAdicionar.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0, true)),
				KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, true), JComponent.WHEN_FOCUSED);

		btAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfProduto.getText().equals("") || tfQuantidade.getText().equals("")
						|| tfPrecoUnitario.getText().equals("")) {
					JOptionPane.showMessageDialog(pnTable, "Preencha todos os campos!");
					tfNumero.requestFocus();
					return;
				}
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				dtm.addRow(new Object[] { tfNumero.getText(), tfProduto.getText(), tfQuantidade.getText(),
						tfPrecoUnitario.getText(), "" + df.format(Integer.parseInt(tfQuantidade.getText())
								* Double.parseDouble(tfPrecoUnitario.getText())) });
				limparCampos();
				calcularTotal();
			}
		});

		btRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] linhas = table.getSelectedRows();
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				for (int i = (linhas.length - 1); i >= 0; --i) {
					dtm.removeRow(linhas[i]);
				}
				calcularTotal();
			}
		});

		ActionListener listenerEnter = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (e.getSource().equals(tfNumero)) {
					tfProduto.requestFocus();
				} else if (e.getSource().equals(tfProduto)) {
					tfQuantidade.requestFocus();
				} else if (e.getSource().equals(tfQuantidade)) {
					tfPrecoUnitario.requestFocus();
				} else if (e.getSource().equals(tfPrecoUnitario)) {
					btAdicionar.requestFocus();
				}
			}
		};

		tfNumero.addActionListener(listenerEnter);
		tfProduto.addActionListener(listenerEnter);
		tfQuantidade.addActionListener(listenerEnter);
		tfPrecoUnitario.addActionListener(listenerEnter);
		tfTotal.addActionListener(listenerEnter);
	}

	private void calcularTotal() {
		double total = 0;
		for (int linha = 0; linha < table.getRowCount(); linha++) {
			String valor = "" + table.getValueAt(linha, 3);
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
			total += Double.parseDouble(valor);
		}
		tfTotal.setText("" + df.format(total));
	}

	private void limparCampos() {
		tfProduto.setText("");
		tfQuantidade.setText("1");
		tfNumero.setText("");
		tfPrecoUnitario.setText("");
		tfNumero.requestFocus();
	}

	public static void main(String[] args) {
		Pedidos pede = new Pedidos();
		pede.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
		pede.setLocation((tela.width - pede.getSize().width) / 2, (tela.height - pede.getSize().height) / 2);
		pede.setUndecorated(true);
		pede.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		pede.setVisible(true);
	}
}
