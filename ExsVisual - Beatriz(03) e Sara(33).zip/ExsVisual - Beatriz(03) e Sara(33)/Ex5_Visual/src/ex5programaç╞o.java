import javax.swing.JOptionPane;

public class ex5programa��o {
	public void Calcular(){
		try{
			double v1 = Double.parseDouble(ex5layout.T1.getText());
			double v2 = Double.parseDouble(ex5layout.T2.getText());
			String operacao = ex5layout.T3.getText();
			double tot;
			
			if(operacao.equals("+"))
			{
				tot = v1 + v2;
				JOptionPane.showMessageDialog(null,
				v1 + " " + operacao + " " + v2 + " = " + tot, 
				"TOTAL", 
				JOptionPane.INFORMATION_MESSAGE);
			}
			
			if(operacao.equals("-"))
			{
				tot = v1 - v2;
				JOptionPane.showMessageDialog(null,
				v1 + " " + operacao + " " + v2 + " = " + tot, 
				"TOTAL", 
				JOptionPane.INFORMATION_MESSAGE);
			}
			
			if(operacao.equals("/"))
			{
				if(v2 != 0)
				{
					tot = v1 / v2;
					JOptionPane.showMessageDialog(null,
					v1 + " " + operacao + " " + v2 + " = " + tot, 
					"TOTAL", 
					JOptionPane.INFORMATION_MESSAGE);
				}
				
				else 
				{
					JOptionPane.showMessageDialog(null, 
					"Erro na leitura de dados. Tente novamente.", 
					"ERRO DE LEITURA", 
					JOptionPane.ERROR_MESSAGE);
				}
			}
			
			if (operacao.equals("*"))
			{
				tot = v1 * v2;
				JOptionPane.showMessageDialog(null,
				v1 + " " + operacao + " " + v2 + " = " + tot, 
				"TOTAL", 
				JOptionPane.INFORMATION_MESSAGE);
			}
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(null, "Digite somente n�meros\n\nTenteNovamente!!!",
					"** Erro de Processamento **",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void Limpar()
	{
		ex5layout.T1.setText(null);
		ex5layout.T2.setText(null);
		ex5layout.T3.setText(null);
		ex5layout.T1.requestFocus();
	}
	
	public void Sa�da(){
	int r=JOptionPane.showConfirmDialog(null, "Deseja sair da Aplica��o?",
			"** Finalizando **",
			JOptionPane.YES_NO_OPTION,
			JOptionPane.QUESTION_MESSAGE);
	if(r==0)
	{
		System.exit(0);
	}
	else
	{
		this.Limpar();
	}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}