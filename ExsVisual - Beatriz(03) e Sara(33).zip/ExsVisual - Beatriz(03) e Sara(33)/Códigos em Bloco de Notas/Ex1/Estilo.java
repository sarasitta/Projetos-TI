
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

	@SuppressWarnings("serial")
public class Estilo extends JFrame implements ActionListener {
		
		JLabel N1, N2, N3, N4, M1;
		static JTextField T1, T2, T3, T4;
		JButton B1, B2, B3;
		Programa��o p=new Programa��o();
		
		public Estilo(){
			setTitle("Programa para a calucular M�dia");
			setBounds(0, 0, 510, 250);
			setResizable(false);
			setLayout(null);
			getContentPane().setBackground(Color.white);
			
			N1=new JLabel("Calcular M�dia", JLabel.CENTER);
			N1.setFont(new Font("verdana",Font.BOLD,24));
			N1.setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
			N1.setBounds(60, 20, 390, 40);
			
			N2=new JLabel("Nota 1:");
			N2.setFont(new Font ("verdana", Font.BOLD,13));
			N2.setBounds(100, 70, 100, 20);
			
			N3=new JLabel("Nota 2:");
			N3.setFont(new Font ("verdana", Font.BOLD,13));
			N3.setBounds(100, 95, 100, 20);
			
			N4=new JLabel("Nota 3:");
			N4.setFont(new Font ("verdana", Font.BOLD,13));
			N4.setBounds(100, 120, 100, 20);
			
			T1=new JTextField();
			T1.setFont(new Font("verdana",Font.BOLD,12));
			T1.setHorizontalAlignment(SwingConstants.CENTER);
			T1.setBounds(200, 70, 100, 20);
			
			T2=new JTextField();
			T2.setFont(new Font("verdana",Font.BOLD,12));
			T2.setHorizontalAlignment(SwingConstants.CENTER);
			T2.setBounds(200, 95, 100, 20);
			
			T3=new JTextField();
			T3.setFont(new Font("verdana",Font.BOLD,12));
			T3.setHorizontalAlignment(SwingConstants.CENTER);
			T3.setBounds(200, 120, 100, 20);
			
			B1=new JButton("Calcular");
			B1.setFont(new Font("verdana",Font.BOLD,12));
			B1.setMnemonic(KeyEvent.VK_P);
			B1.setToolTipText("Calcula as m�dias");
			B1.setBounds(80, 150, 110, 30);
			B1.addActionListener(this);
			
			B2=new JButton("Cancelar");
			B2.setFont(new Font("verdana",Font.BOLD,12));
			B2.setMnemonic(KeyEvent.VK_C);
			B2.setToolTipText("Cancela o n�mero digitado");
			B2.setBounds(200, 150, 110, 30);
			B2.addActionListener(this);
			
			B3=new JButton("Sair");
			B3.setFont(new Font("verdana",Font.BOLD,12));
			B3.setMnemonic(KeyEvent.VK_S);
			B3.setToolTipText("Sair do Programa");
			B3.setBounds(320, 150, 110, 30);
			B3.addActionListener(this);
			
			getContentPane().add(N1);
			getContentPane().add(N2);
			getContentPane().add(N3);
			getContentPane().add(N4);
			getContentPane().add(T1);
			getContentPane().add(T2);
			getContentPane().add(T3);
			getContentPane().add(B1);
			getContentPane().add(B2);
			getContentPane().add(B3);
			
		}
		
		public static void main(String[] args) {
			//M�todo construtor da classe verificar
			Estilo tela = new Estilo();
			//captura a resolu��o da tela que est� usando no momento da aplica��o(usado p/ realizar o c�lculo da localiza��o)
			Dimension frame = Toolkit.getDefaultToolkit().getScreenSize();
			//posiciona a tela no centro emrela��o a resolu��o do pc em q estiver
			tela.setLocation((frame.width-tela.getSize().width)/2, (frame.height-tela.getSize().height/2));
			tela.setUndecorated(true);
			tela.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
			//PRA N�O CONTINUAR RODANDO EM SEGUNDO PLANO AP�S FECHAR O CONTENTPANE
			tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			tela.setVisible(true);

		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource()==B1){
				p.Calcular();
			}
			
			if(e.getSource()==B2){
				p.Limpar();
			}
			
			if(e.getSource()==B3){
				p.Sa�da();
			}
			
		}

	}

