import javax.swing.JOptionPane;

public class Programa��o {
	public void Calcular(){
		try{
			int n1=Integer.parseInt(Estilo.T1.getText());
			int n2=Integer.parseInt(Estilo.T2.getText());
			int n3=Integer.parseInt(Estilo.T3.getText());
			int m=((n1+n2+n3)/3);
			String conceito;
			
			if(m < 5)
			{
				conceito = "Insuficiente";
				JOptionPane.showMessageDialog
				(null," Seu conceito � " + conceito + " e sua m�dia � " + m, conceito,
						JOptionPane.INFORMATION_MESSAGE);
			}
			
			if(m >= 5 && m < 7)
			{	
				conceito = "Regular";
				JOptionPane.showMessageDialog
				(null," Seu conceito � " + conceito + " e sua m�dia � " + m, conceito,
						JOptionPane.INFORMATION_MESSAGE);
			}
			
			if(m >= 7 && m < 9)
			{
				conceito = "Bom";
				JOptionPane.showMessageDialog
				(null," Seu conceito � " + conceito + " e sua m�dia � " + m, conceito, 
						JOptionPane.INFORMATION_MESSAGE);
			}
			
			if(m >= 9)
			{
				conceito = "Muito Bom";
				JOptionPane.showMessageDialog
				(null," seu conceito � " + conceito + " e sua m�dia � " + m, conceito,
						JOptionPane.INFORMATION_MESSAGE);
			}
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(null, "Digite somente n�meros\n\nTenteNovamente!!!",
					"** Erro de Processamento **",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void Limpar()
	{
		Estilo.T1.setText(null);
		Estilo.T2.setText(null);
		Estilo.T3.setText(null);
		Estilo.T1.requestFocus();
	}
	
	public void Sa�da(){
	int r=JOptionPane.showConfirmDialog(null, "Deseja sair da Aplica��o?",
			"** Finalizando **",
			JOptionPane.YES_NO_OPTION,
			JOptionPane.QUESTION_MESSAGE);
	if(r==0)
	{
		System.exit(0);
	}
	else
	{
		this.Limpar();
	}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}