import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRootPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.BorderFactory;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;


@SuppressWarnings("serial")
public class layout extends JFrame implements ActionListener {
	
	JLabel L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, LP1, LP2, LP3;
	static JTextField T1;
	static JTextField T2;
	static JTextField T3;
	static JTextField T4, T5, T6, T7, T8, T9;
	static JButton B1, B2, B3;
	ex2programa��o p=new ex2programa��o();
	
	public layout(){
		setTitle("Programa para C�lculo de Produtos ");
		setBounds(0, 0, 620, 370);
		setResizable(false);
		setLayout(null);
		getContentPane().setBackground(Color.white);
		
		L1=new JLabel("C�lculo de Produtos", JLabel.CENTER);
		L1.setFont(new Font("verdana",Font.BOLD,20));
		L1.setBorder(BorderFactory.createLineBorder(Color.BLACK,2));
		L1.setBounds(100, 20, 390, 25);
		
		///PRODUTO 1
		LP1=new JLabel("Produto 1:");
		LP1.setFont(new Font ("verdana", Font.ITALIC,13));
		LP1.setBounds(40, 50, 100, 20);

		L2=new JLabel("Nome");
		L2.setFont(new Font ("verdana", Font.BOLD,13));
		L2.setBounds(40, 70, 100, 20);
		
		L3=new JLabel("Quantidade");
		L3.setFont(new Font ("verdana", Font.BOLD,13));
		L3.setBounds(40,95, 100, 20);
		
		L4=new JLabel("Valor");
		L4.setFont(new Font ("verdana", Font.BOLD,13));
		L4.setBounds(40, 120, 100, 20);
		
		T1=new JTextField();
		T1.setFont(new Font("verdana",Font.BOLD,12));
		T1.setHorizontalAlignment(SwingConstants.CENTER);
		T1.setBounds(140, 70, 150, 25);
		
		T2=new JTextField();
		T2.setFont(new Font("verdana",Font.BOLD,12));
		T2.setHorizontalAlignment(SwingConstants.CENTER);
		T2.setBounds(140, 95, 150, 25);
		
		T3=new JTextField();
		T3.setFont(new Font("verdana",Font.BOLD,12));
		T3.setHorizontalAlignment(SwingConstants.CENTER);
		T3.setBounds(140, 120, 150, 25);
		
		
		///PRODUTO 2
		LP2=new JLabel("Produto 2:");
		LP2.setFont(new Font ("verdana", Font.ITALIC,13));
		LP2.setBounds(320, 50, 100, 20);
		
		L5=new JLabel("Nome");
		L5.setFont(new Font ("verdana", Font.BOLD,13));
		L5.setBounds(320, 70, 100, 20);
		
		L6=new JLabel("Quantidade");
		L6.setFont(new Font ("verdana", Font.BOLD,13));
		L6.setBounds(320,95, 100, 20);
		
		L7=new JLabel("Valor");
		L7.setFont(new Font ("verdana", Font.BOLD,13));
		L7.setBounds(320, 120, 100, 20);
		
		T4=new JTextField();
		T4.setFont(new Font("verdana",Font.BOLD,12));
		T4.setHorizontalAlignment(SwingConstants.CENTER);
		T4.setBounds(420, 70, 150, 25);
		
		T5=new JTextField();
		T5.setFont(new Font("verdana",Font.BOLD,12));
		T5.setHorizontalAlignment(SwingConstants.CENTER);
		T5.setBounds(420, 95, 150, 25);
		
		T6=new JTextField();
		T6.setFont(new Font("verdana",Font.BOLD,12));
		T6.setHorizontalAlignment(SwingConstants.CENTER);
		T6.setBounds(420, 120, 150, 25);
		
		
		
		
		///PRODUTO 3
		LP3=new JLabel("Produto 3:");
		LP3.setFont(new Font ("verdana", Font.ITALIC,13));
		LP3.setBounds(150, 170, 100, 20);
		
		L8=new JLabel("Nome");
		L8.setFont(new Font ("verdana", Font.BOLD,13));
		L8.setBounds(150, 190, 100, 20);
		
		L9=new JLabel("Quantidade");
		L9.setFont(new Font ("verdana", Font.BOLD,13));
		L9.setBounds(150,215, 100, 20);
		
		L10=new JLabel("Valor");
		L10.setFont(new Font ("verdana", Font.BOLD,13));
		L10.setBounds(150, 240, 100, 20);
		
		T7=new JTextField();
		T7.setFont(new Font("verdana",Font.BOLD,12));
		T7.setHorizontalAlignment(SwingConstants.CENTER);
		T7.setBounds(250, 190, 150, 25);
		
		T8=new JTextField();
		T8.setFont(new Font("verdana",Font.BOLD,12));
		T8.setHorizontalAlignment(SwingConstants.CENTER);
		T8.setBounds(250, 215, 150, 25);
		
		T9=new JTextField();
		T9.setFont(new Font("verdana",Font.BOLD,12));
		T9.setHorizontalAlignment(SwingConstants.CENTER);
		T9.setBounds(250, 240, 150, 25);
		
		
		///BOT�ES
		B1=new JButton("Calcular");
		B1.setFont(new Font("verdana",Font.BOLD,12));
		B1.setMnemonic(KeyEvent.VK_P);
		B1.setToolTipText("Verifica o n�mero digitado");
		B1.setBounds(115, 280, 110, 30);
		B1.addActionListener(this);
		
		B2=new JButton("Cancelar");
		B2.setFont(new Font("verdana",Font.BOLD,12));
		B2.setMnemonic(KeyEvent.VK_C);
		B2.setToolTipText("Cancela o n�mero digitado");
		B2.setBounds(235, 280, 110, 30);
		B2.addActionListener(this);
		
		B3=new JButton("Sair");
		B3.setFont(new Font("verdana",Font.BOLD,12));
		B3.setMnemonic(KeyEvent.VK_S);
		B3.setToolTipText("Sair do Programa");
		B3.setBounds(355, 280, 110, 30);
		B3.addActionListener(this);
		
		getContentPane().add(L1);
		getContentPane().add(L2);
		getContentPane().add(L3);
		getContentPane().add(L4);
		getContentPane().add(L5);
		getContentPane().add(L6);
		getContentPane().add(L7);
		getContentPane().add(L8);
		getContentPane().add(L9);
		getContentPane().add(L10);
		getContentPane().add(LP1);
		getContentPane().add(LP2);
		getContentPane().add(LP3);
		getContentPane().add(T1);
		getContentPane().add(T2);
		getContentPane().add(T3);
		getContentPane().add(T4);
		getContentPane().add(T5);
		getContentPane().add(T6);
		getContentPane().add(T7);
		getContentPane().add(T8);
		getContentPane().add(T9);
		getContentPane().add(B1);
		getContentPane().add(B2);
		getContentPane().add(B3);
		
	}
	
	public static void main(String[] args) {
		//M�todo construtor da classe verificar
		layout tela = new layout();
		//captura a resolu��o da tela que est� usando no momento da aplica��o(usado p/ realizar o c�lculo da localiza��o)
		Dimension frame = Toolkit.getDefaultToolkit().getScreenSize();
		//posiciona a tela no centro emrela��o a resolu��o do pc em q estiver
		tela.setLocation((frame.width-tela.getSize().width)/2, (frame.height-tela.getSize().height/2));
		tela.setUndecorated(true);
		tela.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		//PRA N�O CONTINUAR RODANDO EM SEGUNDO PLANO AP�S FECHAR O CONTENTPANE
		tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tela.setVisible(true);

	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==B1){
			p.Calcular();
		}
		
		if(e.getSource()==B2){
			p.Limpar();
		}
		
		if(e.getSource()==B3){
			p.Sa�da();
		}
		
	}
}
