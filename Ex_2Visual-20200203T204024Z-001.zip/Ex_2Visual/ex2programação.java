import javax.swing.JOptionPane;

public class ex2programa��o {
	public void Calcular(){
		try{
			int quant1=Integer.parseInt(layout.T2.getText());
			int valor1=Integer.parseInt(layout.T3.getText());
			int quant2=Integer.parseInt(layout.T5.getText());
			int valor2=Integer.parseInt(layout.T6.getText());
			int quant3=Integer.parseInt(layout.T8.getText());
			int valor3=Integer.parseInt(layout.T9.getText());
			
			int vt1=quant1*valor1;
			int vt2=quant2*valor2;
			int vt3=quant3*valor3;
			
			int VT=(vt1+vt2+vt3);
			
				JOptionPane.showMessageDialog(null, "O Valor Total da sua Compra �: "+VT+" Valor",
					"** VALOR **",
					JOptionPane.INFORMATION_MESSAGE);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(null, "Digite somente n�meros\n\nTenteNovamente!!!",
					"** Erro de Processamento **",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void Limpar()
	{
		layout.T1.setText(null);
		layout.T2.setText(null);
		layout.T3.setText(null);
		layout.T4.setText(null);
		layout.T5.setText(null);
		layout.T6.setText(null);
		layout.T7.setText(null);
		layout.T8.setText(null);
		layout.T9.setText(null);
		layout.T1.requestFocus();
	}
	
	public void Sa�da(){
	int r=JOptionPane.showConfirmDialog(null, "Deseja sair da Aplica��o?",
			"** Finalizando **",
			JOptionPane.YES_NO_OPTION,
			JOptionPane.QUESTION_MESSAGE);
	if(r==0)
	{
		System.exit(0);
	}
	else
	{
		this.Limpar();
	}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
