
import java.awt.Dimension; 
import java.awt.Toolkit; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.event.KeyEvent; 
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton; 
import javax.swing.JFrame; 
import javax.swing.JRootPane;

@SuppressWarnings("serial") 

public class Deleta_Dados02 extends Deleta_Dados01{

JButton btDeleta,btFechar,btLocalizar; 
	
	public Deleta_Dados02(){ 
		
		btDeleta = new JButton("Deletar"); 
		btDeleta.setBounds(295, 240, 100, 40); 

		btFechar = new JButton("Fechar"); 
		btFechar.setBounds(400, 240, 100, 40); 
		
		btLocalizar = new JButton();
		ImageIcon imageIcon = new ImageIcon("..//AtvAltera//bin//localizar.png");
		btLocalizar.setIcon(imageIcon);
		btLocalizar.setBounds(250, 50, 50, 30);

		add(btDeleta); 
		add(btFechar); 
		add(btLocalizar);

		txtCod.addKeyListener(new KeyListener() { 
			
			public void keyTyped(KeyEvent e) {} 
			public void keyReleased(KeyEvent e) {}
			public void keyPressed(KeyEvent e) { 
				
				if(e.getKeyCode()==KeyEvent.VK_ENTER){ 
					BancoClasse.exibir();} 
				} 
		}); 

		btDeleta.addActionListener(new ActionListener() {
	
			public void actionPerformed(ActionEvent e) {
				BancoClasse.alterar();
			}
		}); 

		btFechar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) { 
			BancoClasse.Fechar(); 
			}
		});
		
		btLocalizar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) { 
		BancoClasse.exibir();}
	});
	}
		
	
	

	public static void main(String[] args) {
		
		Deleta_Dados02 tela = new Deleta_Dados02();
		Dimension frame = Toolkit.getDefaultToolkit().getScreenSize();
		tela.setLocation((frame.width - tela.getSize().width)/2,(frame.height - tela.getSize().height)/2);
		tela.setUndecorated(true);
		tela.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tela.setVisible(true);
	}

}
