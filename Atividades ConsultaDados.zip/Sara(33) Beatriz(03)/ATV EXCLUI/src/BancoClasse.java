
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

class BancoClasse {
	
	public static Connection connection = null;
	public static Statement statement = null;
	public static ResultSet resultSet = null;
	public static final String DRIVER = "com.mysql.jdbc.Driver";
	static final String URL = "jdbc:mysql://localhost:3306/produto";
	
	static String strSql;
		static void Fechar() {
			System.exit(0);
		}

		static void Limpar() { 
			Deleta_Dados02.txtCod.setText(null);
			Deleta_Dados02.txtNomeProd.setText(null);
			Deleta_Dados02.txtDescProd.setText(null);
			Deleta_Dados02.txtValor.setText(null);
			Deleta_Dados02.txtCodFor.setText(null);
			Deleta_Dados02.txtCod.requestFocus();
		}
		
		static void exibir() {
			try {
				Class.forName(DRIVER);
				Connection connection = DriverManager.getConnection(URL,"root",""); 
				statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				
				strSql = "Select * from tabprod where CodProd =" + Deleta_Dados02.txtCod.getText();
				
				resultSet = statement.executeQuery(strSql);
				
				if(resultSet.next()) { 
					Deleta_Dados02.txtCod.setText(resultSet.getString("CodProd"));
					Deleta_Dados02.txtNomeProd.setText(resultSet.getString("NomeProd"));
					Deleta_Dados02.txtDescProd.setText(resultSet.getString("DescProd"));
					Deleta_Dados02.txtValor.setText(resultSet.getString("Valor"));
					Deleta_Dados02.txtCodFor.setText(resultSet.getString("CodFor"));
				}
				else { 
					JOptionPane.showMessageDialog(null, "Produto n�o cadastrado", "DELETAR DADOS", JOptionPane.WARNING_MESSAGE);
					Limpar();
				}
			}
			catch(SQLException erro) { 
				JOptionPane.showMessageDialog(null, "Falha na conex�o" + erro.getMessage());
				System.exit(0);
		}
			catch(Exception erro1) {
				JOptionPane.showMessageDialog(null, "Erro no sistema\n\n" + erro1.getMessage());
				System.exit(0);
			}
			}
		
		static void alterar() {
			try {
				Class.forName(DRIVER);
				Connection connection = DriverManager.getConnection(URL,"root",""); 
				statement = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
				
				strSql = "Delete from tabprod WHERE CodProd = " + Deleta_Dados02.txtCod.getText();
				 statement.executeUpdate(strSql);
				 
				 JOptionPane.showMessageDialog(null, "Produto Deletado com Sucesso !!!",
						 "**** Exclus�o de Dados ****",
						 JOptionPane.INFORMATION_MESSAGE);
				 Limpar();
			}
			catch(SQLException | ClassNotFoundException erro) { 
				JOptionPane.showMessageDialog(null, "Falha na conex�o" + erro.getMessage());
				System.exit(0);
		}
		
			}
		
}