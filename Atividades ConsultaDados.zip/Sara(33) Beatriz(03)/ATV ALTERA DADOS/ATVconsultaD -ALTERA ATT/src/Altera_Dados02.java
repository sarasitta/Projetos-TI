import java.awt.Dimension; 
import java.awt.Toolkit; 
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.event.KeyEvent; 
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JButton; 
import javax.swing.JFrame; 
import javax.swing.JRootPane;

@SuppressWarnings("serial") 

public class Altera_Dados02 extends Altera_Dados_01{
	
	JButton btAlterar,btFechar,btLocalizar; 
	
	public Altera_Dados02(){ 
		
		btAlterar = new JButton("Alterar"); 
		btAlterar.setBounds(295, 240, 100, 40); 
		
		btLocalizar = new JButton();
		ImageIcon imageIcon = new ImageIcon("..//AtvAltera//bin//localizar.png");
		btLocalizar.setIcon(imageIcon);
		btLocalizar.setBounds(250, 50, 50, 30);

		btFechar = new JButton("Fechar"); 
		btFechar.setBounds(400, 240, 100, 40); 

		add(btAlterar); 
		add(btFechar); 
		add(btLocalizar); 

		txtCod.addKeyListener(new KeyListener() { 
			
			public void keyTyped(KeyEvent e) {} 
			public void keyReleased(KeyEvent e) {}
			public void keyPressed(KeyEvent e) { 
				
				if(e.getKeyCode()==KeyEvent.VK_ENTER){ 
					BancoClasse.exibir();} 
				} 
		}); 

		btAlterar.addActionListener(new ActionListener() {
	
			public void actionPerformed(ActionEvent e) {
				BancoClasse.alterar();
			}
		}); 

		btFechar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) { 
			BancoClasse.Fechar(); 
			}
		});
		
		btLocalizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
			BancoClasse.exibir();}
		});
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Altera_Dados02 tela = new Altera_Dados02();
		Dimension frame = Toolkit.getDefaultToolkit().getScreenSize();
		tela.setLocation((frame.width - tela.getSize().width)/2,(frame.height - tela.getSize().height)/2);
		tela.setUndecorated(true);
		tela.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		tela.setVisible(true);
	}

}
