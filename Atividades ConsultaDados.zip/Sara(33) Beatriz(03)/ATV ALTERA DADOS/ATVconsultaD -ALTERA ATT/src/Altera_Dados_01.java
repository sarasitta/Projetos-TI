import java.awt.Font;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class Altera_Dados_01 extends Altera_Dados {
	
	static JTextField txtCod,txtNomeProd, txtDescProd, txtValor, txtCodFor; 
	
	public Altera_Dados_01() {
	
	txtCod = new JTextField(5);
	txtCod.setFont(new Font("verdana",Font.BOLD,14)); 
	txtCod.setBounds(140, 50, 100, 30); 
	
	txtNomeProd = new JTextField();
	txtNomeProd.setFont(new Font("verdana",Font.BOLD,14)); 
	txtNomeProd.setBounds(140, 90, 360, 30); 
	
	txtDescProd = new JTextField(); 
	txtDescProd.setFont(new Font("verdana",Font.BOLD,14)); 
	txtDescProd.setBounds(140, 135, 360, 60); 
	
	txtValor = new JTextField(); 
	txtValor.setFont(new Font("verdana",Font.BOLD,14));
	txtValor.setBounds(140, 205, 100, 30); 
	
	txtCodFor = new JTextField();
	txtCodFor.setFont(new Font("verdana",Font.BOLD,14));
	txtCodFor.setBounds(140, 250, 100, 30); 
	
	add(txtCod);
	add(txtNomeProd);
	add(txtDescProd);
	add(txtValor);
	add(txtCodFor); 
	} 


}
