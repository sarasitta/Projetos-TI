import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;


public class Altera_Dados extends JFrame {
	
	JLabel lblAltera, lblCod, lblNomeProd, lblDescProd, lblValor, lblCodFor;
	static JTextField txtCod;
	static JTextField txtNomeProd;
	static JTextField txtDescProd;
	static JTextField txtValor;
	JTextField txtCodFor;
	
	public Altera_Dados() {
		
		setTitle("Alterar Dados");
		setBounds(0,0,550,350);
		setResizable(false);
		getContentPane().setLayout(null);
		getContentPane().setBackground(Color.white);
		
		lblAltera = new JLabel("Altera��o");
		lblAltera.setFont(new Font("Verdana", Font.BOLD,32));
		lblAltera.setForeground(Color.blue);
		lblAltera.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		lblAltera.setBounds(110,05,330,42);
		
		lblCod= new JLabel("C�digo"); 
		lblCod.setFont(new Font("Verdana",Font.BOLD,14)); 
		lblCod.setBounds(66, 55, 130, 30); 
		
		lblNomeProd= new JLabel("Produto"); 
		lblNomeProd.setFont(new Font("Verdana",Font.BOLD,14)); 
		lblNomeProd.setBounds(60, 96, 130, 30); 
		
		lblDescProd= new JLabel("Descri��o"); 
		lblDescProd.setFont(new Font("Verdana",Font.BOLD,14));
		lblDescProd.setBounds(50, 170, 130, 30); 
		
		lblValor= new JLabel("Valor"); 
		lblValor.setFont(new Font("Verdana",Font.BOLD,14));
		lblValor.setBounds(80, 213, 130, 30); 

		lblCodFor= new JLabel("Fornecedor"); 
		lblCodFor.setFont(new Font("Verdana",Font.BOLD,14)); 
		lblCodFor.setBounds(35, 255, 130, 30); 
		
		add(lblAltera);
		add(lblCod); 
		add(lblNomeProd); 
		add(lblDescProd); 
		add(lblValor); 
		add(lblCodFor); 

	}

}
