package pedidos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class skrr extends JFrame {
	JPanel pnmain, pntable;
	JButton btRemover, btAdicionar;
	JScrollPane scrolltable;
	JTable table;
	JLabel lbnum, lbtot, lbprod, lbpuni, lbqtd;
	JTextField tfprod, tfnum, tftot, tfpuni, tfqtd;
	DecimalFormat df = new DecimalFormat("#,###.00");

	public skrr() {
		setBounds(150, 50, 500, 450);
		setResizable(false);
		getContentPane().setBackground(new Color(220, 220, 220));
		getContentPane().setLayout(null);

		lbprod = new JLabel("Produto");
		lbqtd = new JLabel("Quantidade");
		lbpuni = new JLabel("Pre�o Unit�rio");
		lbnum = new JLabel("N�mero do Pedido");
		lbtot = new JLabel("Total do Pedido");

		tfprod = new JTextField();
		tfpuni = new JTextField();
		tfqtd = new JTextField();
		tfnum = new JTextField();
		tftot = new JTextField();
		tftot.setEnabled(false);
		tftot.setHorizontalAlignment(SwingConstants.RIGHT);

		btAdicionar = new JButton("Adicionar");
		btAdicionar.setToolTipText("Adiciona um item ao pedido");
		btRemover = new JButton("Remover");
		btRemover.setToolTipText("Remove os itens selecionados");

		lbprod.setBounds(15, 40, 100, 25);
		lbqtd.setBounds(225, 40, 100, 25);
		lbpuni.setBounds(310, 40, 100, 25);
		lbnum.setBounds(15, 10, 120, 25);
		lbtot.setBounds(278, 360, 100, 25);

		tfprod.setBounds(15, 65, 200, 25);
		tfqtd.setBounds(225, 65, 70, 25);
		tfpuni.setBounds(310, 65, 90, 25);
		tfnum.setBounds(130, 10, 50, 25);
		tftot.setBounds(375, 360, 100, 25);

		btAdicionar.setBounds(15, 100, 100, 22);
		btRemover.setBounds(125, 100, 100, 22);

		pnmain = new JPanel();
		pnmain.setLayout(null);
		pnmain.setBounds(0, 0, 500, 400);

		pnmain.add(lbnum);
		pnmain.add(lbtot);
		pnmain.add(tfnum);
		pnmain.add(tftot);
		pnmain.add(lbprod);
		pnmain.add(tfprod);
		pnmain.add(lbqtd);
		pnmain.add(tfqtd);
		pnmain.add(lbpuni);
		pnmain.add(tfpuni);

		pntable = new JPanel(new BorderLayout());
		pntable.setBorder(new TitledBorder("Itens do Pedido"));
		scrolltable = new JScrollPane();
		df.setMinimumFractionDigits(2);
		df.setMaximumFractionDigits(2);
		pnmain.add(btAdicionar);
		pnmain.add(btRemover);

		DefaultTableModel tableModel = new DefaultTableModel(
				new String[] { "Item", "Produto", "Qtde.", "Pre�o Uni", "Total" }, 0) {

			public boolean isCellEditable(int row, int col) {
				if (col == 4) {
					return false;
				}
				return true;
			}
		};

		table = new JTable(tableModel);
		DefaultTableCellRenderer Direita = new DefaultTableCellRenderer();
	Direita.setHorizontalAlignment(SwingConstants.RIGHT);
		DefaultTableCellRenderer Centro = new DefaultTableCellRenderer();
		Centro.setHorizontalAlignment(SwingConstants.CENTER);

		table.getColumnModel().getColumn(0).setPreferredWidth(50);
		table.getColumnModel().getColumn(0).setCellRenderer(Centro);

		table.getColumnModel().getColumn(1).setPreferredWidth(150);

		table.getColumnModel().getColumn(2).setPreferredWidth(57);
		table.getColumnModel().getColumn(2).setCellRenderer(Centro);

		table.getColumnModel().getColumn(3).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setCellRenderer(Direita);

		table.getColumnModel().getColumn(4).setPreferredWidth(100);
		table.getColumnModel().getColumn(4).setCellRenderer(Direita);

		table.getTableHeader().setResizingAllowed(false);
		table.getTableHeader().setReorderingAllowed(false);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		scrolltable.setViewportView(table);
		pntable.add(scrolltable);
		pntable.setBounds(10, 130, 470, 230);
		pnmain.add(pntable);
		add(pnmain);

		btAdicionar.registerKeyboardAction(
				btAdicionar.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0, false)),
				KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), JComponent.WHEN_FOCUSED);
		btAdicionar.registerKeyboardAction(
				btAdicionar.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0, true)),
				KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, true), JComponent.WHEN_FOCUSED);

		btAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfprod.getText().equals("") || tfqtd.getText().equals("")
						|| tfpuni.getText().equals("")) {
					JOptionPane.showMessageDialog(pntable, "Preencha todos os campos!");
					tfnum.requestFocus();
					return;
				}
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				dtm.addRow(new Object[] { tfnum.getText(), tfprod.getText(), tfqtd.getText(),
						tfpuni.getText(), "" + df.format(Integer.parseInt(tfqtd.getText())
								* Double.parseDouble(tfpuni.getText())) });
				limparCampos();
				calcularTotal();
			}
		});

		btRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] linhas = table.getSelectedRows();
				DefaultTableModel dtm = (DefaultTableModel) table.getModel();
				for (int i = (linhas.length - 1); i >= 0; --i) {
					dtm.removeRow(linhas[i]);
				}
				calcularTotal();
			}
		});

		ActionListener listenerEnter = new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (e.getSource().equals(tfnum)) {
					tfprod.requestFocus();
				} else if (e.getSource().equals(tfprod)) {
					tfqtd.requestFocus();
				} else if (e.getSource().equals(tfqtd)) {
					tfpuni.requestFocus();
				} else if (e.getSource().equals(tfpuni)) {
					btAdicionar.requestFocus();
				}
			}
		};

		tfnum.addActionListener(listenerEnter);
		tfprod.addActionListener(listenerEnter);
		tfqtd.addActionListener(listenerEnter);
		tfpuni.addActionListener(listenerEnter);
		tftot.addActionListener(listenerEnter);
	}

	private void calcularTotal() {
		double total = 0;
		for (int linha = 0; linha < table.getRowCount(); linha++) {
			String valor = "" + table.getValueAt(linha, 3);
			valor = valor.replace(".", "");
			valor = valor.replace(",", ".");
			total += Double.parseDouble(valor);
		}
		tftot.setText("" + df.format(total));
	}

	private void limparCampos() {
		tfprod.setText("");
		tfqtd.setText("1");
		tfnum.setText("");
		tfpuni.setText("");
		tfnum.requestFocus();
	}

	public static void main(String[] args) {
		skrr p = new skrr();
		p.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
		p.setLocation((tela.width - p.getSize().width) / 2, (tela.height - p.getSize().height) / 2);
		p.setUndecorated(true);
		p.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);
		p.setVisible(true);
	}
}
