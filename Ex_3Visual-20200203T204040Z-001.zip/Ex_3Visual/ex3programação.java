import javax.swing.JOptionPane;

public class ex3programa��o {
	public void Calcular(){
		try{
			double km = Double.parseDouble(ex3layout.T1.getText());
			double kmvalor =km/8.5;
			
			JOptionPane.showMessageDialog(null, 
					"Valor gasto com combust�vel: " + kmvalor + " litros.", 
					"VALOR GASTO", 
					JOptionPane.INFORMATION_MESSAGE);
			
		}
		catch(Exception ex){
			JOptionPane.showMessageDialog(null, "Digite somente n�meros\n\nTenteNovamente!!!",
					"** Erro de Processamento **",
					JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void Limpar()
	{
		ex3layout.T1.setText(null);
		ex3layout.T1.requestFocus();
	}
	
	public void Sa�da(){
	int r=JOptionPane.showConfirmDialog(null, "Deseja sair da Aplica��o?",
			"** Finalizando **",
			JOptionPane.YES_NO_OPTION,
			JOptionPane.QUESTION_MESSAGE);
	if(r==0)
	{
		System.exit(0);
	}
	else
	{
		this.Limpar();
	}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}