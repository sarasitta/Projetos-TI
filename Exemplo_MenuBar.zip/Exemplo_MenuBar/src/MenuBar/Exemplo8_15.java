package MenuBar;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Exemplo8_15 extends Exemplo8_14 implements ActionListener{
	
	public Exemplo8_15()
	{
		B1.addActionListener(this);
		B2.addActionListener(this);
		B3.addActionListener(this);
		B4.addActionListener(this);
		B5.addActionListener(this);
		B6.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==B5)
		{
			Lx1.setVisible(true);
			Lx2.setVisible(false);
			Lx3.setVisible(false);
			Lx4.setVisible(false);
			Lx5.setVisible(false);
			Lx6.setVisible(false);
		}
		
		if(e.getSource()==B6)
		{
			Lx2.setVisible(true);
			Lx1.setVisible(false);
			Lx3.setVisible(false);
			Lx4.setVisible(false);
			Lx5.setVisible(false);
			Lx6.setVisible(false);
		}
		
		if(e.getSource()==B1)
		{
			Lx3.setVisible(true);
			Lx1.setVisible(false);
			Lx2.setVisible(false);
			Lx4.setVisible(false);
			Lx5.setVisible(false);
			Lx6.setVisible(false);
		}
		
		if(e.getSource()==B2)
		{
			Lx4.setVisible(true);
			Lx1.setVisible(false);
			Lx2.setVisible(false);
			Lx3.setVisible(false);
			Lx5.setVisible(false);
			Lx6.setVisible(false);
		}
		
		if(e.getSource()==B3)
		{
			Lx5.setVisible(true);
			Lx1.setVisible(false);
			Lx2.setVisible(false);
			Lx3.setVisible(false);
			Lx4.setVisible(false);
			Lx6.setVisible(false);
		}
		
		if(e.getSource()==B4)
		{
			Lx6.setVisible(true);
			Lx1.setVisible(false);
			Lx2.setVisible(false);
			Lx3.setVisible(false);
			Lx4.setVisible(false);
			Lx5.setVisible(false);
		}
	}

	

}
