package MenuBar;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;




import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;


@SuppressWarnings("serial")
public class Menu extends JFrame {

	private JMenuBar mnBarra;
	private JMenu mnArquivo, mnExemplos;
	private JMenuItem miSair, miMedia, miJPane, miComboBox;
	private JDesktopPane med, exJp, cBox;
	
	public Menu(){
		
		setTitle("Menu Principal");
		setBackground(Color.white);
		setBounds(0, 0, 800, 600);
		
		mnBarra= new JMenuBar();
		mnArquivo= new JMenu("Op��es");
		mnArquivo.setMnemonic('O');
		
		mnExemplos= new JMenu("Programas");
		mnExemplos.setMnemonic('P');
		
		miSair= new JMenuItem("Sair");
		miSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.ALT_MASK));
		mnArquivo.add(miSair);
		
		miMedia= new JMenuItem("C�lculo da M�dia");
		miMedia.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.ALT_MASK));
		mnExemplos.add(miMedia);
		
		miJPane= new JMenuItem("Ex_JPane");
		miJPane.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,ActionEvent.ALT_MASK));
		mnExemplos.add(miJPane);
		
		miComboBox= new JMenuItem("Combo Box");
		miComboBox.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,ActionEvent.ALT_MASK));
		mnExemplos.add(miComboBox);
		
		mnBarra.add(mnArquivo);
		mnBarra.add(mnExemplos);
		setJMenuBar(mnBarra);
		
		miSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(JOptionPane.showConfirmDialog(null,
				    "Deseja Sair do Programa?",
				    "*** FINALIZANDO ***",
				    JOptionPane.YES_NO_OPTION,
				    JOptionPane.QUESTION_MESSAGE)== JOptionPane.YES_OPTION)
					System.exit(0);
			}
		});
		
		miMedia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				med= new JDesktopPane();
				Media mi= new Media();
				setContentPane(med);
				med.add(mi);
				med.validate();	
			}
		});
	
	
	
	    miJPane.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			exJp= new JDesktopPane();
			Exemplo8_15 ex15= new Exemplo8_15();
			setContentPane(exJp);
			exJp.add(ex15);
			exJp.validate();	
		}
	});
	    
	    miComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cBox= new JDesktopPane();
				Combo_Box_img cb= new Combo_Box_img();
				setContentPane(cBox);
				cBox.add(cb);
				cBox.validate();	
			}
		});
}
	
	
	
	
	
	public static void main(String[] args) {
		Menu frame= new Menu();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension tela= Toolkit.getDefaultToolkit().getScreenSize();
		frame.setLocation((tela.width-frame.getSize().width)/2, 
				           (tela.height-frame.getSize().height)/2);
		frame.setUndecorated(true);
		frame.getRootPane().setWindowDecorationStyle(JRootPane.INFORMATION_DIALOG);
		frame.setVisible(true);

	}

}
