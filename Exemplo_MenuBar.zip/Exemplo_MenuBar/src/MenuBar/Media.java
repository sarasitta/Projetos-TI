package MenuBar;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


@SuppressWarnings("serial")
public class Media extends JInternalFrame {

	JLabel L1,L2,L3,L4;
	JButton B1,B2,B3;
	JTextField T1,T2;
	
	public Media(){
		setTitle("C�lculo da M�dia");
		setBounds(210, 180, 410, 230);
		setResizable(false);
		setClosable(true);
		setMaximizable(true);
		setIconifiable(true);
		setBackground(Color.white);
		setVisible(true);
		getContentPane().setLayout(null);
		
		L1= new JLabel("1� Nota");
		L1.setBounds(30, 30, 80, 30);
		
		L2= new JLabel("2� Nota");
		L2.setBounds(30, 60, 80, 30);
		
		L3= new JLabel("M�dia");
		L3.setBounds(30, 90, 80, 30);
		
		L4=new JLabel();
		L4.setBorder(BorderFactory.createLineBorder(Color.black));
		L4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		L4.setBounds(80, 90, 80, 20);
		
		T1= new JTextField();
		T1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		T1.setBounds(80, 30, 80, 20);
		
		T2= new JTextField();
		T2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		T2.setBounds(80, 60, 80, 20);
		
		B1=new JButton("Calcular");
		B1.setMnemonic(KeyEvent.VK_C);
		B1.setToolTipText("Calcular m�dia entre duas notas");
		B1.setBounds(30, 130, 100, 25);
		
		B2=new JButton("Cancelar");
		B2.setMnemonic(KeyEvent.VK_A);
		B2.setToolTipText("Cancelar o calculo da m�dia entre duas notas");
		B2.setBounds(150, 130, 100, 25);
		
		B3=new JButton("Fechar");
		B3.setMnemonic(KeyEvent.VK_F);
		B3.setToolTipText("Fechar programa");
		B3.setBounds(270, 130, 100, 25);
		
		getContentPane().add(L1);
		getContentPane().add(L2);
		getContentPane().add(L3);
		getContentPane().add(L4);
		getContentPane().add(T1);
		getContentPane().add(T2);
		getContentPane().add(B1);
		getContentPane().add(B2);
		getContentPane().add(B3);
		
		B1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				try{
					String nota1,nota2;
					float n1=0,n2=0;
					nota1=T1.getText();
					nota1=nota1.replace(',', '.');
					nota2=T2.getText();
					nota2=nota2.replace(',', '.');
					n1=Float.parseFloat(nota1);
					n2=Float.parseFloat(nota2);
					if(n1<0 || n1>10 ||n2<0 ||n2>10){
						JOptionPane.showMessageDialog(null,
								"Notas Inv�lidas !!!",
								"*** ERRO DE ENTRADA ***",
								 JOptionPane.ERROR_MESSAGE);
						Limpar();
					}else{
						L4.setText(String.valueOf((n1+n2)/2));
					}
					
				}catch(NumberFormatException erro){
					JOptionPane.showMessageDialog(null,
							"Digite somente n�meros",
							"*** ERRO DE ENTRADA DE DADOS",
							JOptionPane.ERROR_MESSAGE);
					Limpar();
				}
			}
		});
		
		B2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpar();
			}
		});
		
		B3.addActionListener(new ActionListener() {
		
			public void actionPerformed(ActionEvent e) {
				if(JOptionPane.showConfirmDialog(null,
					    "Deseja Sair do Programa?",
					    "*** FINALIZANDO ***",
					    JOptionPane.YES_NO_OPTION,
					    JOptionPane.QUESTION_MESSAGE)== JOptionPane.YES_OPTION);
			setVisible(false);	
			}
		});
	}	
		public void Limpar(){
			T1.setText(null);
			T2.setText(null);
			L4.setText("");
			T1.requestFocus();
		}
	}

