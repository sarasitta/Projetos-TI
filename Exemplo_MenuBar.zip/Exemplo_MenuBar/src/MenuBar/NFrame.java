package MenuBar;

import java.awt.Color;

import javax.swing.*;

@SuppressWarnings("serial")
public class NFrame extends JInternalFrame{

public NFrame() 	
   {
	   setLocation(50,100);
	   setTitle("JFrame Personalizado");
	   setBounds(0,0,600,450);
	   getRootPane().setWindowDecorationStyle(JRootPane.ERROR_DIALOG);
	   getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 5));
	   setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
new NFrame().setVisible(true);
	}

}
