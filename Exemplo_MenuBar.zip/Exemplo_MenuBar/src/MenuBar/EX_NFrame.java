

import java.awt.Color;

import javax.swing.*;

@SuppressWarnings("serial")
public class EX_NFrame extends JFrame{

public EX_NFrame() 	
   {
	   setLocation(50,100);
	   setTitle("JFrame Personalizado");
	   setBounds(0,0,600,550);
	   setUndecorated(true);
	   getRootPane().setWindowDecorationStyle(JRootPane.COLOR_CHOOSER_DIALOG);
	   getRootPane().setBorder(BorderFactory.createLineBorder(new Color(200,230,180), 5));
	   setDefaultCloseOperation(EXIT_ON_CLOSE);
   }
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
new EX_NFrame().setVisible(true);
	}

}
