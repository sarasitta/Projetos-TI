

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class JListaFotos extends EX_NFrame{
	
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("rawtypes")
	private JList lsFotos;
	@SuppressWarnings("rawtypes")
	private DefaultListModel dlm;
	private ImageIcon Imagem1;
	private JScrollPane sp;
	private JLabel lblImagem, lblBorda;
	@SuppressWarnings("unused")
	private JPanel p;
	private String caminho="D://NFrame//Imagens//";
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public JListaFotos(){
		setTitle("Fotos");
		setBounds(0,0,400,300);
		setResizable(false);
		setLayout(null);
		getContentPane().setBackground(new Color(200,240,150));
		
		lblBorda = new JLabel();
		lblBorda.setFont(new Font("Time New Romans",Font.BOLD, 14));
		lblBorda.setBorder(BorderFactory.createLineBorder(Color.black, 3));
		lblBorda.setBounds(155,40,170,150);
		dlm = new DefaultListModel();
		for (int i =1; i <= 18; i++){
			dlm.addElement("Foto" + i);
		}
		
		lsFotos = new JList(dlm);
		sp = new JScrollPane(lsFotos);
		sp.setBounds(50,40,70,150);
		Imagem1 = new ImageIcon();
		lblImagem = new JLabel(Imagem1);
		lblImagem.setBounds(150,25,180,180);
		
		add(sp);
		add(lblImagem);
		add(lblBorda);
		
		lsFotos.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e){
				Imagem1 = new ImageIcon(caminho+lsFotos.getSelectedValue()+ ".jpg");
				lblImagem.setIcon(Imagem1);
			}
		});
		
			}
		
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
JListaFotos frame = new JListaFotos();
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
frame.setLocation((tela.width - frame.getSize().width)/2,
		(tela.height - frame.getSize().height)/2);
frame.setVisible(true);
	}

}
