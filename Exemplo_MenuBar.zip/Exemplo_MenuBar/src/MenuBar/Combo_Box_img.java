package MenuBar;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JRootPane;

public class Combo_Box_img extends JInternalFrame {
	
	 static final long serialVersionUID = 1L;
	@SuppressWarnings("rawtypes")
	 JComboBox lsFotos;
     ImageIcon Imagem1;
	 JLabel lblImagem;
	 String caminho="D://Exemplo_MenuBar//Imagens//";
	
	@SuppressWarnings({"rawtypes","unchecked"})
	public Combo_Box_img() {
		
		setTitle("Combo Imagens");
		setBounds(0,0,500,300);
		setResizable(false);
		setLayout(null);
		setVisible(true);
		getContentPane().setLayout(null);
		setClosable(true);
		lsFotos = new JComboBox();
		
		for (int i =1; i <= 18; i++){
			lsFotos.addItem("Foto" + i);
		}
		
		lsFotos.setBounds(10,50,200,30);
		Imagem1 = new ImageIcon();
		lblImagem = new JLabel(Imagem1);
		lblImagem.setBorder(BorderFactory.createLineBorder(Color.BLACK, 5));
		lblImagem.setBounds(230,10,180,180);
		
		add(lsFotos);
		add(lblImagem);
		
		lsFotos.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Imagem1 = new ImageIcon(caminho + lsFotos.getSelectedItem() + ".jpg");
				lblImagem.setIcon(Imagem1);
			}
			
		}); 
	}
	
	
		
	}

	


